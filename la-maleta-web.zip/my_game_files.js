var gamefiles = ['acsetup.cfg','LaMaleta.ags','English.tra','speech.vox'];

// fill this array with ALL your game files
// and put them in the same location
